import factoryAbi from './factoryAbi.json'

export const FACTORY_ABI = factoryAbi;
export const FACTORY_ADDRESS = '0x1F98431c8aD98523631AE4a59f267346ea31F984';